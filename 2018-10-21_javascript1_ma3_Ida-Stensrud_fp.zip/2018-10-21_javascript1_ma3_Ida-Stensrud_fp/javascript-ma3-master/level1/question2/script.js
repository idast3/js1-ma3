//Console.log out elements in JSON file

var authorElements = {
	"video": [{
		"id": 12312412312,
		"name": "Ecuaciones Diferenciales",
		"url": "/video/math/edo/12312412312",
		"author": {
			"data": [{
				"name_author": "Alejandro Morales",
				"url": "/author/alejandro-morales",
				"type": "master"
			}]
		}
	}]
};

for (var i = 0; i < authorElements.video.length; i++) {
  console.log(authorElements.video[i].id);
	console.log(authorElements.video[i].name);
	console.log(authorElements.video[i].url);
	console.log(authorElements.video[i].author);
	console.log(authorElements.video[i].author.data[i].name_author);
	console.log(authorElements.video[i].author.data[i].url);
	console.log(authorElements.video[i].author.data[i].type);
}
