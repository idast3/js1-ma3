//Use RegEx to validate form

// Validate name
function checkFirstName(firstName) {
  var firstNameRequired = /[a-zA-Z.-]/g;
  if (firstName.match(firstNameRequired)) {
    console.log("This name is valid");
  } else {
    console.log("This is not a valid name");
  }
};

// Validate last name
function checkLastName(lastName) {
  var lastNameRequired = /[a-zA-Z.-]/g;
  if (lastName.match(lastNameRequired)) {
    console.log("This name is valid");
  } else {
    console.log("This is not a valid name");
  }
};

// Validate phone number
function checkPhoneNum(phoneNum) {
  var phoneNumRequired = /\d\d\d\d\d\d\d\d/;
  if (phoneNum.match(phoneNumRequired)) {
    console.log("This number is valid");
  } else {
    console.log("This is not a valid number");
  }
};

// Validate email address
function checkEmailAdr(emailAdr) {
  var emailRequired = /^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.[a-zA-Z]{2,4}$/;
  if (emailAdr.match(emailRequired)) {
    console.log("This email address is valid");
  } else {
    console.log("This is not a valid email address");
  }
};

// Validate form when submit is clicked
var form = document.querySelector('form');

form.addEventListener('submit', function(f){
  f.preventDefault();
  checkFirstName(this.firstName.value);
  checkLastName(this.lastName.value);
  checkPhoneNum(this.phoneNum.value);
  checkEmailAdr(this.emailAdr.value);
});
